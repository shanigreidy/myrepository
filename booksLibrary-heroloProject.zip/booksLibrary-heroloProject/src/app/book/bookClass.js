"use strict";
var Book = (function () {
    function Book(title, author, date) {
        this.title = title;
        this.author = author;
        this.date = date;
    }
    return Book;
}());
exports.Book = Book;
//# sourceMappingURL=bookClass.js.map