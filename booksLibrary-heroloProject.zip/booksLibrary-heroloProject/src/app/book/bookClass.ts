export class Book {
    constructor(
        public title: string,
        public author: string,
        public date: string
    ) {  }
}