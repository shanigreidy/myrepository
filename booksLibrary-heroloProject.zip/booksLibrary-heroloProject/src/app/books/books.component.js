"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var books_service_1 = require("../services/books.service");
var capitalize_pipe_1 = require("../pipes/capitalize.pipe");
var bookClass_1 = require("../book/bookClass");
var BooksComponent = (function () {
    function BooksComponent(booksService, capitalizePipe) {
        var _this = this;
        this.booksService = booksService;
        this.capitalizePipe = capitalizePipe;
        this.book = new bookClass_1.Book('', '', '');
        this.hideTitleIsExistsMsg = true;
        this.hideInvalidDateMsg = true;
        this.hideSuccessMsg = true;
        booksService.getBooks().subscribe(function (books) { return _this.books = books; });
    }
    BooksComponent.prototype.onAddBookButtonClicked = function () {
        this.formTitle = 'Add new Book';
        this.functionInvoke = 'add';
        this.formAction = 'Add';
    };
    BooksComponent.prototype.onAddBook = function () {
        this.book.title = this.capitalizePipe.transform(this.book.title);
        if (this.isValidInput(this.book.title, this.book.author, this.book.date, "addBook")) {
            this.onSuccessAddOrEditBook("addBook");
            this.hideTitleIsExistsMsg = true;
            this.hideInvalidDateMsg = true;
            var newBook = new bookClass_1.Book(this.book.title, this.book.author, this.book.date);
            this.books.push(newBook);
            this.resetParameters();
        }
    };
    BooksComponent.prototype.onEditBookButtonClicked = function (book) {
        this.formTitle = 'Edit Book';
        this.functionInvoke = 'edit';
        this.formAction = 'Save';
        this.editBookTitle = book.title;
        this.book.title = book.title;
        this.book.author = book.author;
        this.book.date = book.date;
    };
    BooksComponent.prototype.onSaveEditBook = function () {
        this.book.title = this.capitalizePipe.transform(this.book.title);
        if (this.isValidInput(this.book.title, this.book.author, this.book.date, "editBook")) {
            this.onSuccessAddOrEditBook("editBook");
            this.hideTitleIsExistsMsg = true;
            this.hideInvalidDateMsg = true;
            for (var index in this.books) {
                if (this.books[index].title == this.editBookTitle) {
                    this.books[index].title = this.book.title;
                    this.books[index].author = this.book.author;
                    this.books[index].date = this.book.date;
                }
            }
        }
    };
    BooksComponent.prototype.onDeleteBook = function (title) {
        if (confirm("Are you sure you want to delete this book?") == true) {
            this.books = this.books.filter(function (book) { return book.title !== title; });
        }
    };
    BooksComponent.prototype.isValidInput = function (title, author, date, action) {
        if (this.isTitleExists(this.book.title, action)) {
            this.hideTitleIsExistsMsg = false;
            this.hideInvalidDateMsg = true;
            return false;
        }
        else if (!this.isValidDate(this.book.date)) {
            this.hideInvalidDateMsg = false;
            this.hideTitleIsExistsMsg = true;
            return false;
        }
        return true;
    };
    BooksComponent.prototype.isTitleExists = function (title, action) {
        for (var _i = 0, _a = this.books; _i < _a.length; _i++) {
            var book = _a[_i];
            if (action == "addBook") {
                if (book.title == title) {
                    return true;
                }
            }
            else {
                if (book.title !== this.editBookTitle && book.title == title) {
                    return true;
                }
            }
        }
        return false;
    };
    BooksComponent.prototype.isValidDate = function (date) {
        var datePattern = /^\d{2}\/\d{2}\/\d{4}$/;
        var dateArray = date.split("/");
        if (date.match(datePattern)) {
            var newDate = new Date(dateArray[2], dateArray[1] - 1, dateArray[0]);
            if (newDate && (newDate.getMonth() + 1) == dateArray[1]) {
                return true;
            }
        }
        return false;
    };
    BooksComponent.prototype.onSuccessAddOrEditBook = function (action) {
        var _this = this;
        this.hideSuccessMsg = false;
        setTimeout(function () { return _this.hideSuccessMsg = true; }, 2000);
        if (action == "addBook") {
            this.successMsgAction = "added";
        }
        else {
            this.successMsgAction = "saved";
        }
    };
    BooksComponent.prototype.resetParameters = function () {
        this.hideTitleIsExistsMsg = true;
        this.hideInvalidDateMsg = true;
        this.book.title = '';
        this.book.author = '';
        this.book.date = '';
    };
    return BooksComponent;
}());
BooksComponent = __decorate([
    core_1.Component({
        selector: 'books',
        templateUrl: 'app/books/books.component.html',
        styleUrls: ['app/books/books.component.css'],
        providers: [books_service_1.BooksService, capitalize_pipe_1.CapitalizePipe]
    }),
    __metadata("design:paramtypes", [books_service_1.BooksService, capitalize_pipe_1.CapitalizePipe])
], BooksComponent);
exports.BooksComponent = BooksComponent;
//# sourceMappingURL=books.component.js.map